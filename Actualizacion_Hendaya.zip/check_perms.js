const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./prisma/dev.db');

db.all(`
  SELECT u.username, r.name as roleName, r.permissions 
  FROM User u 
  JOIN Role r ON u.roleId = r.id 
  WHERE u.username = 'admin'
`, [], (err, rows) => {
  if (err) throw err;
  console.log(JSON.stringify(rows, null, 2));
});

db.close();

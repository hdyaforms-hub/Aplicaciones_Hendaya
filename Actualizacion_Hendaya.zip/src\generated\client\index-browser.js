
Object.defineProperty(exports, "__esModule", { value: true });

const {
  Decimal,
  objectEnumValues,
  makeStrictEnum,
  Public,
  getRuntime,
  skip
} = require('./runtime/index-browser.js')


const Prisma = {}

exports.Prisma = Prisma
exports.$Enums = {}

/**
 * Prisma Client JS version: 5.22.0
 * Query Engine version: 605197351a3c8bdd595af2d2a9bc3025bca48ea2
 */
Prisma.prismaVersion = {
  client: "5.22.0",
  engine: "605197351a3c8bdd595af2d2a9bc3025bca48ea2"
}

Prisma.PrismaClientKnownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientKnownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)};
Prisma.PrismaClientUnknownRequestError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientUnknownRequestError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientRustPanicError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientRustPanicError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientInitializationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientInitializationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.PrismaClientValidationError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`PrismaClientValidationError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.NotFoundError = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`NotFoundError is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.Decimal = Decimal

/**
 * Re-export of sql-template-tag
 */
Prisma.sql = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`sqltag is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.empty = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`empty is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.join = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`join is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.raw = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`raw is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.validator = Public.validator

/**
* Extensions
*/
Prisma.getExtensionContext = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.getExtensionContext is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}
Prisma.defineExtension = () => {
  const runtimeName = getRuntime().prettyName;
  throw new Error(`Extensions.defineExtension is unable to run in this browser environment, or has been bundled for the browser (running in ${runtimeName}).
In case this error is unexpected for you, please report it in https://pris.ly/prisma-prisma-bug-report`,
)}

/**
 * Shorthand utilities for JSON filtering
 */
Prisma.DbNull = objectEnumValues.instances.DbNull
Prisma.JsonNull = objectEnumValues.instances.JsonNull
Prisma.AnyNull = objectEnumValues.instances.AnyNull

Prisma.NullTypes = {
  DbNull: objectEnumValues.classes.DbNull,
  JsonNull: objectEnumValues.classes.JsonNull,
  AnyNull: objectEnumValues.classes.AnyNull
}



/**
 * Enums
 */

exports.Prisma.TransactionIsolationLevel = makeStrictEnum({
  ReadUncommitted: 'ReadUncommitted',
  ReadCommitted: 'ReadCommitted',
  RepeatableRead: 'RepeatableRead',
  Serializable: 'Serializable'
});

exports.Prisma.RoleScalarFieldEnum = {
  id: 'id',
  name: 'name',
  description: 'description',
  permissions: 'permissions',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.UserScalarFieldEnum = {
  id: 'id',
  username: 'username',
  email: 'email',
  passwordHash: 'passwordHash',
  name: 'name',
  roleId: 'roleId',
  isActive: 'isActive',
  isDeleted: 'isDeleted',
  mustChangePassword: 'mustChangePassword',
  rbds: 'rbds',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.PMPAScalarFieldEnum = {
  id: 'id',
  ano: 'ano',
  mes: 'mes',
  licitacion: 'licitacion',
  ute: 'ute',
  rbd: 'rbd',
  programa: 'programa',
  estrato: 'estrato',
  nivel: 'nivel',
  servicioLic: 'servicioLic',
  raceqJunaeb: 'raceqJunaeb',
  servicio: 'servicio',
  uploadedBy: 'uploadedBy',
  createdAt: 'createdAt'
};

exports.Prisma.ColegiosScalarFieldEnum = {
  id: 'id',
  colut: 'colut',
  colRBD: 'colRBD',
  colRBDDV: 'colRBDDV',
  insid: 'insid',
  institucion: 'institucion',
  sucursal: 'sucursal',
  nombreEstablecimiento: 'nombreEstablecimiento',
  direccionEstablecimiento: 'direccionEstablecimiento',
  comuna: 'comuna',
  uploadedBy: 'uploadedBy'
};

exports.Prisma.IngRacionScalarFieldEnum = {
  id: 'id',
  usuario: 'usuario',
  ubicacion: 'ubicacion',
  fechaSistema: 'fechaSistema',
  fechaIngreso: 'fechaIngreso',
  rbd: 'rbd',
  licId: 'licId',
  nombreEstablecimiento: 'nombreEstablecimiento',
  ano: 'ano',
  mes: 'mes',
  programa: 'programa',
  estrato: 'estrato',
  desayunoIng: 'desayunoIng',
  almuerzoIng: 'almuerzoIng',
  onceIng: 'onceIng',
  colacionIng: 'colacionIng',
  cenaIng: 'cenaIng',
  tercerServicioIng: 'tercerServicioIng',
  totalIng: 'totalIng',
  desayunoAsig: 'desayunoAsig',
  almuerzoAsig: 'almuerzoAsig',
  onceAsig: 'onceAsig',
  colacionAsig: 'colacionAsig',
  cenaAsig: 'cenaAsig',
  tercerServicioAsig: 'tercerServicioAsig',
  totalAsig: 'totalAsig',
  tasaPreparacion: 'tasaPreparacion',
  observacion: 'observacion'
};

exports.Prisma.ProductosScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  codigo: 'codigo',
  unidad: 'unidad',
  tipoProducto: 'tipoProducto'
};

exports.Prisma.EmailConfigScalarFieldEnum = {
  id: 'id',
  email: 'email',
  password: 'password',
  provider: 'provider',
  updatedBy: 'updatedBy',
  updatedAt: 'updatedAt'
};

exports.Prisma.ListaCorreoScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  descripcion: 'descripcion',
  para: 'para',
  cc: 'cc',
  sucursalId: 'sucursalId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.NotificacionPantallaScalarFieldEnum = {
  id: 'id',
  codigoPantalla: 'codigoPantalla',
  listaCorreoId: 'listaCorreoId',
  activa: 'activa',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.PlantillaCorreoScalarFieldEnum = {
  id: 'id',
  codigoPantalla: 'codigoPantalla',
  asunto: 'asunto',
  cuerpo: 'cuerpo',
  updatedAt: 'updatedAt'
};

exports.Prisma.MultaServicioScalarFieldEnum = {
  id: 'id',
  codigo: 'codigo',
  nombre: 'nombre'
};

exports.Prisma.LicitacionScalarFieldEnum = {
  licId: 'licId',
  licitacionHomologada: 'licitacionHomologada',
  estado: 'estado',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.AspectoEEScalarFieldEnum = {
  id: 'id',
  licId: 'licId',
  letra: 'letra',
  descripcion: 'descripcion',
  formula: 'formula',
  solucionable: 'solucionable',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SucursalScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  region: 'region',
  comuna: 'comuna',
  direccion: 'direccion',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.PresupuestoScalarFieldEnum = {
  id: 'id',
  ano: 'ano',
  sucursalId: 'sucursalId',
  montoAnual: 'montoAnual',
  usuario: 'usuario',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SolicitudPanScalarFieldEnum = {
  id: 'id',
  ut: 'ut',
  licId: 'licId',
  rbd: 'rbd',
  nombreSolicitante: 'nombreSolicitante',
  fechaSolicitud: 'fechaSolicitud',
  solicitud: 'solicitud',
  cantidad: 'cantidad',
  fechaGestacion: 'fechaGestacion',
  servicio: 'servicio',
  motivo: 'motivo'
};

exports.Prisma.UTScalarFieldEnum = {
  codUT: 'codUT',
  licId: 'licId',
  estado: 'estado',
  sucursalId: 'sucursalId',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SolicitudGasScalarFieldEnum = {
  id: 'id',
  ut: 'ut',
  licId: 'licId',
  rbd: 'rbd',
  nombreSolicitante: 'nombreSolicitante',
  fechaSolicitud: 'fechaSolicitud',
  distribuidor: 'distribuidor',
  tipoGas: 'tipoGas',
  cantidadLitro: 'cantidadLitro',
  cilindro: 'cilindro',
  cantidad: 'cantidad',
  observacion: 'observacion',
  createdAt: 'createdAt'
};

exports.Prisma.RetiroSaldoHeaderScalarFieldEnum = {
  id: 'id',
  folio: 'folio',
  tipoOperacion: 'tipoOperacion',
  rbd: 'rbd',
  nombreEstablecimiento: 'nombreEstablecimiento',
  ut: 'ut',
  licId: 'licId',
  sucursal: 'sucursal',
  fecha: 'fecha',
  supervisor: 'supervisor',
  nombreAutoriza: 'nombreAutoriza',
  rutAutoriza: 'rutAutoriza',
  firmaBase64: 'firmaBase64',
  createdAt: 'createdAt'
};

exports.Prisma.RetiroSaldoDetailScalarFieldEnum = {
  id: 'id',
  headerId: 'headerId',
  codigoProducto: 'codigoProducto',
  nombreProducto: 'nombreProducto',
  cantidad: 'cantidad',
  createdAt: 'createdAt'
};

exports.Prisma.Mat_ConsumoGasScalarFieldEnum = {
  id: 'id',
  rbd: 'rbd',
  litros: 'litros',
  cantidad: 'cantidad',
  meses: 'meses',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.FormDefinitionScalarFieldEnum = {
  id: 'id',
  title: 'title',
  description: 'description',
  fields: 'fields',
  createdBy: 'createdBy',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  isActive: 'isActive',
  formCode: 'formCode',
  formVersion: 'formVersion',
  formDate: 'formDate',
  areaId: 'areaId'
};

exports.Prisma.AreaScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.FormScheduleScalarFieldEnum = {
  id: 'id',
  formId: 'formId',
  startDay: 'startDay',
  startTime: 'startTime',
  endDay: 'endDay',
  endTime: 'endTime',
  createdAt: 'createdAt'
};

exports.Prisma.FormSubmissionScalarFieldEnum = {
  id: 'id',
  formId: 'formId',
  data: 'data',
  submittedBy: 'submittedBy',
  submittedAt: 'submittedAt'
};

exports.Prisma.Mat_ConsumoGasHistoryScalarFieldEnum = {
  id: 'id',
  rbd: 'rbd',
  litros: 'litros',
  cantidad: 'cantidad',
  meses: 'meses',
  old_litros: 'old_litros',
  old_cantidad: 'old_cantidad',
  old_meses: 'old_meses',
  observacion: 'observacion',
  user: 'user',
  createdAt: 'createdAt'
};

exports.Prisma.AnexoScalarFieldEnum = {
  id: 'id',
  sucursal: 'sucursal',
  cargo: 'cargo',
  correo: 'correo',
  telefono1: 'telefono1',
  telefono2: 'telefono2',
  telefono3: 'telefono3',
  telefono4: 'telefono4',
  nombre: 'nombre',
  cumpleano: 'cumpleano',
  contacto: 'contacto',
  nota: 'nota',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MatrizRiesgo2026ScalarFieldEnum = {
  id: 'id',
  fecha: 'fecha',
  usuario: 'usuario',
  ut: 'ut',
  rbd: 'rbd',
  nombreEstablecimiento: 'nombreEstablecimiento',
  sucursal: 'sucursal',
  patio_servicio: 'patio_servicio',
  basurero_patio: 'basurero_patio',
  zonas_libres_residuos: 'zonas_libres_residuos',
  vias_acceso_pavimentas: 'vias_acceso_pavimentas',
  caseta_gas: 'caseta_gas',
  bombona_estado: 'bombona_estado',
  focos_insalubridad: 'focos_insalubridad',
  obs_patio: 'obs_patio',
  adjuntos_patio: 'adjuntos_patio',
  bodega_mp: 'bodega_mp',
  ventilacion_bodega: 'ventilacion_bodega',
  cielos_bodega: 'cielos_bodega',
  puertas_bodega: 'puertas_bodega',
  ventanas_bodega: 'ventanas_bodega',
  malla_bodega: 'malla_bodega',
  pisos_bodega: 'pisos_bodega',
  paredes_bodega: 'paredes_bodega',
  uniones_bodega: 'uniones_bodega',
  iluminacion_estado_bodega: 'iluminacion_estado_bodega',
  iluminacion_protegida_bodega: 'iluminacion_protegida_bodega',
  iluminacion_adecuada_bodega: 'iluminacion_adecuada_bodega',
  botiquin: 'botiquin',
  extintores: 'extintores',
  conexiones_electricas_bodega: 'conexiones_electricas_bodega',
  equipos_frio_sin_visor: 'equipos_frio_sin_visor',
  obs_bodega: 'obs_bodega',
  adjuntos_bodega: 'adjuntos_bodega',
  tamano_cocina: 'tamano_cocina',
  ventilacion_cocina: 'ventilacion_cocina',
  puertas_cocina: 'puertas_cocina',
  ventanas_cocina: 'ventanas_cocina',
  malla_cocina: 'malla_cocina',
  pisos_cocina: 'pisos_cocina',
  paredes_cocina: 'paredes_cocina',
  uniones_cocina: 'uniones_cocina',
  drenajes: 'drenajes',
  inclinacion_pisos: 'inclinacion_pisos',
  cielos_cocina: 'cielos_cocina',
  lava_fondos: 'lava_fondos',
  lavamanos_manipulacion: 'lavamanos_manipulacion',
  dispensador_jabon_papel: 'dispensador_jabon_papel',
  calefon: 'calefon',
  pre_wash: 'pre_wash',
  extractor_campana: 'extractor_campana',
  carros_bandejas: 'carros_bandejas',
  iluminacion_estado_cocina: 'iluminacion_estado_cocina',
  iluminacion_protegida_cocina: 'iluminacion_protegida_cocina',
  iluminacion_adecuada_cocina: 'iluminacion_adecuada_cocina',
  basureros_tapa_cocina: 'basureros_tapa_cocina',
  llaves_sifon_cocina: 'llaves_sifon_cocina',
  canerias_agua: 'canerias_agua',
  canerias_gas: 'canerias_gas',
  conexiones_electricas_cocina: 'conexiones_electricas_cocina',
  trampas_residuos: 'trampas_residuos',
  obs_cocina: 'obs_cocina',
  adjuntos_cocina: 'adjuntos_cocina',
  bano_exclusivo: 'bano_exclusivo',
  sin_conexion_directa: 'sin_conexion_directa',
  puertas_bano: 'puertas_bano',
  malla_bano: 'malla_bano',
  pisos_bano: 'pisos_bano',
  paredes_bano: 'paredes_bano',
  lavamanos_caliente_fria: 'lavamanos_caliente_fria',
  ducha: 'ducha',
  cortina: 'cortina',
  dispensadores_jabon_bano: 'dispensadores_jabon_bano',
  estanque_tapa_wc: 'estanque_tapa_wc',
  espejo: 'espejo',
  basurero_tapa_bano: 'basurero_tapa_bano',
  llaves_sifon_bano: 'llaves_sifon_bano',
  dispensador_papel: 'dispensador_papel',
  iluminaria_bano: 'iluminaria_bano',
  obs_bano: 'obs_bano',
  adjuntos_bano: 'adjuntos_bano',
  obs_generales: 'obs_generales',
  adjunto_sostenedor: 'adjunto_sostenedor',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ColegiosMatrizScalarFieldEnum = {
  id: 'id',
  colRBD: 'colRBD',
  nombreEstablecimiento: 'nombreEstablecimiento',
  institucion: 'institucion',
  sucursal: 'sucursal',
  colut: 'colut',
  isActive: 'isActive',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MatrizConfigPreguntaScalarFieldEnum = {
  id: 'id',
  preguntaId: 'preguntaId',
  seccion: 'seccion',
  gravedad: 'gravedad',
  probabilidad: 'probabilidad',
  nivelRiesgo: 'nivelRiesgo',
  updatedAt: 'updatedAt'
};

exports.Prisma.MatrizConfigSemestreScalarFieldEnum = {
  id: 'id',
  anio: 'anio',
  fechaFin1: 'fechaFin1',
  updatedAt: 'updatedAt'
};

exports.Prisma.MatrizMitigacionScalarFieldEnum = {
  id: 'id',
  matrizId: 'matrizId',
  preguntaId: 'preguntaId',
  fechaSolucion: 'fechaSolucion',
  adjuntos: 'adjuntos',
  usuario: 'usuario',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.TrabajoPreventivoScalarFieldEnum = {
  id: 'id',
  ut: 'ut',
  sucursal: 'sucursal',
  licitacion: 'licitacion',
  rbd: 'rbd',
  nombreEstablecimiento: 'nombreEstablecimiento',
  folioOT: 'folioOT',
  tipoTrabajo: 'tipoTrabajo',
  fechaTrabajo: 'fechaTrabajo',
  documentoAsociado: 'documentoAsociado',
  boletasFacturas: 'boletasFacturas',
  montoMateriales: 'montoMateriales',
  montoManoObra: 'montoManoObra',
  observacion: 'observacion',
  usuario: 'usuario',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.RetornoProductosAlertaScalarFieldEnum = {
  id: 'id',
  titulo: 'titulo',
  observacion: 'observacion',
  horas: 'horas',
  estado: 'estado',
  color: 'color',
  archivos: 'archivos',
  usuarioCreacion: 'usuarioCreacion',
  fechaCreacion: 'fechaCreacion',
  usuarioCierre: 'usuarioCierre',
  fechaCierre: 'fechaCierre',
  conclusionFinal: 'conclusionFinal'
};

exports.Prisma.RetornoProductosSucursalEstadoScalarFieldEnum = {
  id: 'id',
  alertaId: 'alertaId',
  sucursalId: 'sucursalId',
  estado: 'estado',
  usuarioCierre: 'usuarioCierre',
  fechaCierre: 'fechaCierre'
};

exports.Prisma.RetornoProductosMovimientoScalarFieldEnum = {
  id: 'id',
  alertaId: 'alertaId',
  sucursalId: 'sucursalId',
  usuarioRegistro: 'usuarioRegistro',
  comentario: 'comentario',
  archivos: 'archivos',
  fechaRegistro: 'fechaRegistro'
};

exports.Prisma.RetornoProductosAlertaHistorialEliminadoScalarFieldEnum = {
  id: 'id',
  alertaIdOriginal: 'alertaIdOriginal',
  tituloAlerta: 'tituloAlerta',
  observacionAlerta: 'observacionAlerta',
  motivoEliminacion: 'motivoEliminacion',
  usuarioEliminador: 'usuarioEliminador',
  fechaEliminacion: 'fechaEliminacion'
};

exports.Prisma.PreparacionesScalarFieldEnum = {
  id: 'id',
  licitacion: 'licitacion',
  numeroPreparacion: 'numeroPreparacion',
  nombrePreparacion: 'nombrePreparacion',
  numeroPrograma: 'numeroPrograma',
  programa: 'programa',
  numeroCocina: 'numeroCocina',
  cocina: 'cocina',
  numeroArea: 'numeroArea',
  area: 'area',
  codigoProducto: 'codigoProducto',
  nombreProducto: 'nombreProducto',
  codigoSubServicio: 'codigoSubServicio',
  nombreSubServicio: 'nombreSubServicio',
  cantPreparacion: 'cantPreparacion',
  porcentajePerdida: 'porcentajePerdida',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MinutasScalarFieldEnum = {
  id: 'id',
  numeroMinuta: 'numeroMinuta',
  licitacion: 'licitacion',
  numeroPrograma: 'numeroPrograma',
  programa: 'programa',
  numeroCocina: 'numeroCocina',
  cocina: 'cocina',
  dia: 'dia',
  mes: 'mes',
  anio: 'anio',
  numeroPreparacion: 'numeroPreparacion',
  sucid: 'sucid',
  codigoServicio: 'codigoServicio',
  nombreServicio: 'nombreServicio',
  codigoEnlace: 'codigoEnlace',
  nombreEnlace: 'nombreEnlace',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.RacionesScalarFieldEnum = {
  id: 'id',
  licitacion: 'licitacion',
  numeroServicio: 'numeroServicio',
  servicio: 'servicio',
  numeroCocina: 'numeroCocina',
  numeroArea: 'numeroArea',
  numeroEnlace: 'numeroEnlace',
  numeroLocacion: 'numeroLocacion',
  locacion: 'locacion',
  numeroPrograma: 'numeroPrograma',
  programa: 'programa',
  mes: 'mes',
  anio: 'anio',
  fecha: 'fecha',
  estadoRacion: 'estadoRacion',
  numeroBeneficiario: 'numeroBeneficiario',
  beneficiario: 'beneficiario',
  cantidad: 'cantidad',
  rbd: 'rbd',
  ut: 'ut',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.CapCertificacionHeaderScalarFieldEnum = {
  id: 'id',
  rbd: 'rbd',
  fecha: 'fecha',
  servicio: 'servicio',
  programa: 'programa',
  area: 'area',
  racionesBase: 'racionesBase',
  racionesDigitadas: 'racionesDigitadas',
  racionesPreparar: 'racionesPreparar',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt',
  usuario: 'usuario',
  motivoCambioAdmin: 'motivoCambioAdmin'
};

exports.Prisma.CapCertificacionDetailScalarFieldEnum = {
  id: 'id',
  headerId: 'headerId',
  numeroMinuta: 'numeroMinuta',
  nombrePreparacion: 'nombrePreparacion',
  nombreProducto: 'nombreProducto',
  grsRac: 'grsRac',
  grsTotal: 'grsTotal'
};

exports.Prisma.ElementosEsenciales_CabScalarFieldEnum = {
  id: 'id',
  licitacion: 'licitacion',
  licId: 'licId',
  folio: 'folio',
  fechaSupervision: 'fechaSupervision',
  rbd: 'rbd',
  region: 'region',
  comuna: 'comuna',
  servicio: 'servicio',
  servicioManual: 'servicioManual',
  observacionManualServicio: 'observacionManualServicio',
  esServicioManual: 'esServicioManual',
  horaInicio: 'horaInicio',
  hora: 'hora',
  obsALosIncumplimiento: 'obsALosIncumplimiento',
  nombreArchivo: 'nombreArchivo',
  link: 'link',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ElementosEsenciales_DetScalarFieldEnum = {
  id: 'id',
  cabId: 'cabId',
  aspecto: 'aspecto',
  observacionesOMedioDeVerificacion: 'observacionesOMedioDeVerificacion',
  co: 'co',
  nc: 'nc',
  na: 'na'
};

exports.Prisma.UTMScalarFieldEnum = {
  id: 'id',
  anho: 'anho',
  mes: 'mes',
  monto: 'monto',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.Multas_Elementos_Esenciales_CabScalarFieldEnum = {
  id: 'id',
  folioOriginal: 'folioOriginal',
  rbd: 'rbd',
  fechaSupervision: 'fechaSupervision',
  licitacion: 'licitacion',
  montoTotalCalculado: 'montoTotalCalculado',
  estadoCalculo: 'estadoCalculo',
  usuarioCalculo: 'usuarioCalculo',
  fechaCalculo: 'fechaCalculo'
};

exports.Prisma.Multas_Elementos_Esenciales_DetScalarFieldEnum = {
  id: 'id',
  cabId: 'cabId',
  letraAspecto: 'letraAspecto',
  descripcion: 'descripcion',
  formulaAplicada: 'formulaAplicada',
  montoMulta: 'montoMulta',
  variablesUsadas: 'variablesUsadas'
};

exports.Prisma.DescargaPaeLogScalarFieldEnum = {
  id: 'id',
  ano: 'ano',
  mes: 'mes',
  institucion: 'institucion',
  rbd: 'rbd',
  urlGenerada: 'urlGenerada',
  usuario: 'usuario',
  fechaDescarga: 'fechaDescarga'
};

exports.Prisma.PaeOnlineCabScalarFieldEnum = {
  id: 'id',
  institucion: 'institucion',
  mes: 'mes',
  ano: 'ano',
  folio: 'folio',
  establecimiento: 'establecimiento',
  comuna: 'comuna',
  rbd: 'rbd',
  estrato: 'estrato',
  programa: 'programa',
  licitacion: 'licitacion',
  certificacion: 'certificacion',
  createdAt: 'createdAt'
};

exports.Prisma.PaeOnlineDetScalarFieldEnum = {
  id: 'id',
  cabId: 'cabId',
  dia: 'dia',
  serCompletas: 'serCompletas',
  serIncompletas: 'serIncompletas',
  codProducto: 'codProducto',
  noServido: 'noServido',
  codCausa: 'codCausa',
  totalRaciones: 'totalRaciones'
};

exports.Prisma.CodigoCausaScalarFieldEnum = {
  id: 'id',
  descripcion: 'descripcion',
  imputable: 'imputable',
  definicion: 'definicion',
  createdAt: 'createdAt'
};

exports.Prisma.TipoVehiculoScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.VehiculoScalarFieldEnum = {
  id: 'id',
  patente: 'patente',
  utId: 'utId',
  sucursalId: 'sucursalId',
  tipoVehiculoId: 'tipoVehiculoId',
  licId: 'licId',
  utIds: 'utIds',
  vigente: 'vigente',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.JefeZonalScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  apellido: 'apellido',
  correo: 'correo',
  vigente: 'vigente',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.JefeZonalLicitacionScalarFieldEnum = {
  jefeZonalId: 'jefeZonalId',
  licitacionId: 'licitacionId'
};

exports.Prisma.JefeZonalSucursalScalarFieldEnum = {
  jefeZonalId: 'jefeZonalId',
  sucursalId: 'sucursalId'
};

exports.Prisma.JefeZonalVehiculoScalarFieldEnum = {
  jefeZonalId: 'jefeZonalId',
  vehiculoId: 'vehiculoId'
};

exports.Prisma.JefeOperacionScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  apellido: 'apellido',
  correo: 'correo',
  jefeZonalId: 'jefeZonalId',
  vigente: 'vigente',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.JefeOperacionVehiculoScalarFieldEnum = {
  jefeOperacionId: 'jefeOperacionId',
  vehiculoId: 'vehiculoId'
};

exports.Prisma.SupervisorScalarFieldEnum = {
  id: 'id',
  nombre: 'nombre',
  apellido: 'apellido',
  correo: 'correo',
  jefeOperacionId: 'jefeOperacionId',
  jefeZonalId: 'jefeZonalId',
  vigente: 'vigente',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.SupervisorVehiculoScalarFieldEnum = {
  supervisorId: 'supervisorId',
  vehiculoId: 'vehiculoId'
};

exports.Prisma.SupervisorRbdScalarFieldEnum = {
  id: 'id',
  supervisorId: 'supervisorId',
  rbd: 'rbd',
  createdAt: 'createdAt'
};

exports.Prisma.DistanciaCacheScalarFieldEnum = {
  id: 'id',
  sucursal: 'sucursal',
  rbd: 'rbd',
  distanciaKm: 'distanciaKm',
  duracionMin: 'duracionMin',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.ConsumoApiGoogleScalarFieldEnum = {
  id: 'id',
  mes: 'mes',
  anio: 'anio',
  cantidad: 'cantidad',
  updatedAt: 'updatedAt'
};

exports.Prisma.Cab_LeePdfEstandarPaeScalarFieldEnum = {
  id: 'id',
  NombreArchivoPdf: 'NombreArchivoPdf',
  Licitacion: 'Licitacion',
  Folio: 'Folio',
  Res_Sanitaria_N: 'Res_Sanitaria_N',
  Nombre_Num_establecimiento: 'Nombre_Num_establecimiento',
  RBD: 'RBD',
  Region: 'Region',
  Comuna: 'Comuna',
  Fecha_Supervision: 'Fecha_Supervision',
  Porcentaje_cumplimiento_final: 'Porcentaje_cumplimiento_final',
  Observaciones: 'Observaciones',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.Det_LeePdfEstandarPaeScalarFieldEnum = {
  id: 'id',
  cabeceraId: 'cabeceraId',
  Infraestructura: 'Infraestructura',
  Calificacion: 'Calificacion',
  Descripcion: 'Descripcion',
  Comprometiendo_Inocuidad: 'Comprometiendo_Inocuidad',
  Tipo_NC: 'Tipo_NC',
  Otros_Comentarios: 'Otros_Comentarios'
};

exports.Prisma.MatrizT_CabeceraScalarFieldEnum = {
  id: 'id',
  licId: 'licId',
  anio: 'anio',
  titulo: 'titulo',
  estado: 'estado',
  instrucciones: 'instrucciones',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MatrizT_DetalleScalarFieldEnum = {
  id: 'id',
  cabeceraId: 'cabeceraId',
  preguntaNombre: 'preguntaNombre',
  tipoRespuesta: 'tipoRespuesta',
  obligatorio: 'obligatorio',
  seccion: 'seccion',
  orden: 'orden',
  gravedad: 'gravedad',
  probabilidad: 'probabilidad',
  nivelRiesgo: 'nivelRiesgo',
  justificacion: 'justificacion',
  riesgoSignificativo: 'riesgoSignificativo',
  recursoNecesario: 'recursoNecesario',
  resultadoEsperado: 'resultadoEsperado',
  respImplementacion: 'respImplementacion',
  respSeguimiento: 'respSeguimiento',
  evidenciaCumplimiento: 'evidenciaCumplimiento',
  evidenciaEficacia: 'evidenciaEficacia'
};

exports.Prisma.MatrizT_RespuestasCabeceraScalarFieldEnum = {
  id: 'id',
  cabeceraId: 'cabeceraId',
  usuario: 'usuario',
  fechaIngreso: 'fechaIngreso',
  supervisorNombre: 'supervisorNombre',
  supervisorCorreo: 'supervisorCorreo',
  licId: 'licId',
  ut: 'ut',
  rbd: 'rbd',
  createdAt: 'createdAt',
  updatedAt: 'updatedAt'
};

exports.Prisma.MatrizT_RespuestasDetalleScalarFieldEnum = {
  id: 'id',
  respuestaCabeceraId: 'respuestaCabeceraId',
  preguntaId: 'preguntaId',
  valor: 'valor',
  adjuntoUrl: 'adjuntoUrl'
};

exports.Prisma.SortOrder = {
  asc: 'asc',
  desc: 'desc'
};

exports.Prisma.QueryMode = {
  default: 'default',
  insensitive: 'insensitive'
};

exports.Prisma.NullsOrder = {
  first: 'first',
  last: 'last'
};


exports.Prisma.ModelName = {
  Role: 'Role',
  User: 'User',
  PMPA: 'PMPA',
  Colegios: 'Colegios',
  IngRacion: 'IngRacion',
  Productos: 'Productos',
  EmailConfig: 'EmailConfig',
  ListaCorreo: 'ListaCorreo',
  NotificacionPantalla: 'NotificacionPantalla',
  PlantillaCorreo: 'PlantillaCorreo',
  MultaServicio: 'MultaServicio',
  Licitacion: 'Licitacion',
  AspectoEE: 'AspectoEE',
  Sucursal: 'Sucursal',
  Presupuesto: 'Presupuesto',
  SolicitudPan: 'SolicitudPan',
  UT: 'UT',
  SolicitudGas: 'SolicitudGas',
  RetiroSaldoHeader: 'RetiroSaldoHeader',
  RetiroSaldoDetail: 'RetiroSaldoDetail',
  Mat_ConsumoGas: 'Mat_ConsumoGas',
  FormDefinition: 'FormDefinition',
  Area: 'Area',
  FormSchedule: 'FormSchedule',
  FormSubmission: 'FormSubmission',
  Mat_ConsumoGasHistory: 'Mat_ConsumoGasHistory',
  Anexo: 'Anexo',
  MatrizRiesgo2026: 'MatrizRiesgo2026',
  ColegiosMatriz: 'ColegiosMatriz',
  MatrizConfigPregunta: 'MatrizConfigPregunta',
  MatrizConfigSemestre: 'MatrizConfigSemestre',
  MatrizMitigacion: 'MatrizMitigacion',
  TrabajoPreventivo: 'TrabajoPreventivo',
  RetornoProductosAlerta: 'RetornoProductosAlerta',
  RetornoProductosSucursalEstado: 'RetornoProductosSucursalEstado',
  RetornoProductosMovimiento: 'RetornoProductosMovimiento',
  RetornoProductosAlertaHistorialEliminado: 'RetornoProductosAlertaHistorialEliminado',
  Preparaciones: 'Preparaciones',
  Minutas: 'Minutas',
  Raciones: 'Raciones',
  CapCertificacionHeader: 'CapCertificacionHeader',
  CapCertificacionDetail: 'CapCertificacionDetail',
  ElementosEsenciales_Cab: 'ElementosEsenciales_Cab',
  ElementosEsenciales_Det: 'ElementosEsenciales_Det',
  UTM: 'UTM',
  Multas_Elementos_Esenciales_Cab: 'Multas_Elementos_Esenciales_Cab',
  Multas_Elementos_Esenciales_Det: 'Multas_Elementos_Esenciales_Det',
  DescargaPaeLog: 'DescargaPaeLog',
  PaeOnlineCab: 'PaeOnlineCab',
  PaeOnlineDet: 'PaeOnlineDet',
  CodigoCausa: 'CodigoCausa',
  TipoVehiculo: 'TipoVehiculo',
  Vehiculo: 'Vehiculo',
  JefeZonal: 'JefeZonal',
  JefeZonalLicitacion: 'JefeZonalLicitacion',
  JefeZonalSucursal: 'JefeZonalSucursal',
  JefeZonalVehiculo: 'JefeZonalVehiculo',
  JefeOperacion: 'JefeOperacion',
  JefeOperacionVehiculo: 'JefeOperacionVehiculo',
  Supervisor: 'Supervisor',
  SupervisorVehiculo: 'SupervisorVehiculo',
  SupervisorRbd: 'SupervisorRbd',
  DistanciaCache: 'DistanciaCache',
  ConsumoApiGoogle: 'ConsumoApiGoogle',
  Cab_LeePdfEstandarPae: 'Cab_LeePdfEstandarPae',
  Det_LeePdfEstandarPae: 'Det_LeePdfEstandarPae',
  MatrizT_Cabecera: 'MatrizT_Cabecera',
  MatrizT_Detalle: 'MatrizT_Detalle',
  MatrizT_RespuestasCabecera: 'MatrizT_RespuestasCabecera',
  MatrizT_RespuestasDetalle: 'MatrizT_RespuestasDetalle'
};

/**
 * This is a stub Prisma Client that will error at runtime if called.
 */
class PrismaClient {
  constructor() {
    return new Proxy(this, {
      get(target, prop) {
        let message
        const runtime = getRuntime()
        if (runtime.isEdge) {
          message = `PrismaClient is not configured to run in ${runtime.prettyName}. In order to run Prisma Client on edge runtime, either:
- Use Prisma Accelerate: https://pris.ly/d/accelerate
- Use Driver Adapters: https://pris.ly/d/driver-adapters
`;
        } else {
          message = 'PrismaClient is unable to run in this browser environment, or has been bundled for the browser (running in `' + runtime.prettyName + '`).'
        }
        
        message += `
If this is unexpected, please open an issue: https://pris.ly/prisma-prisma-bug-report`

        throw new Error(message)
      }
    })
  }
}

exports.PrismaClient = PrismaClient

Object.assign(exports, Prisma)

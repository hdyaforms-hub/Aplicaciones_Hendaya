-- CreateTable
CREATE TABLE "MatrizT_Cabecera" (
    "id" TEXT NOT NULL,
    "licId" INTEGER NOT NULL,
    "anio" INTEGER NOT NULL,
    "titulo" TEXT NOT NULL,
    "estado" BOOLEAN NOT NULL DEFAULT true,
    "instrucciones" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MatrizT_Cabecera_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MatrizT_Detalle" (
    "id" TEXT NOT NULL,
    "cabeceraId" TEXT NOT NULL,
    "preguntaNombre" TEXT NOT NULL,
    "tipoRespuesta" TEXT NOT NULL,
    "obligatorio" BOOLEAN NOT NULL DEFAULT false,
    "seccion" TEXT NOT NULL,
    "orden" INTEGER NOT NULL DEFAULT 0,
    "gravedad" INTEGER,
    "probabilidad" INTEGER,
    "nivelRiesgo" INTEGER,
    "justificacion" TEXT,
    "riesgoSignificativo" TEXT,
    "recursoNecesario" TEXT,
    "resultadoEsperado" TEXT,
    "respImplementacion" TEXT,
    "respSeguimiento" TEXT,
    "evidenciaCumplimiento" TEXT,
    "evidenciaEficacia" TEXT,

    CONSTRAINT "MatrizT_Detalle_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MatrizT_RespuestasCabecera" (
    "id" TEXT NOT NULL,
    "cabeceraId" TEXT NOT NULL,
    "usuario" TEXT NOT NULL,
    "fechaIngreso" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "supervisorNombre" TEXT NOT NULL,
    "supervisorCorreo" TEXT NOT NULL,
    "licId" INTEGER NOT NULL,
    "ut" INTEGER NOT NULL,
    "rbd" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "MatrizT_RespuestasCabecera_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "MatrizT_RespuestasDetalle" (
    "id" TEXT NOT NULL,
    "respuestaCabeceraId" TEXT NOT NULL,
    "preguntaId" TEXT NOT NULL,
    "valor" TEXT,
    "adjuntoUrl" TEXT,

    CONSTRAINT "MatrizT_RespuestasDetalle_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "MatrizT_Cabecera" ADD CONSTRAINT "MatrizT_Cabecera_licId_fkey" FOREIGN KEY ("licId") REFERENCES "Licitacion"("licId") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MatrizT_Detalle" ADD CONSTRAINT "MatrizT_Detalle_cabeceraId_fkey" FOREIGN KEY ("cabeceraId") REFERENCES "MatrizT_Cabecera"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MatrizT_RespuestasCabecera" ADD CONSTRAINT "MatrizT_RespuestasCabecera_cabeceraId_fkey" FOREIGN KEY ("cabeceraId") REFERENCES "MatrizT_Cabecera"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MatrizT_RespuestasDetalle" ADD CONSTRAINT "MatrizT_RespuestasDetalle_respuestaCabeceraId_fkey" FOREIGN KEY ("respuestaCabeceraId") REFERENCES "MatrizT_RespuestasCabecera"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MatrizT_RespuestasDetalle" ADD CONSTRAINT "MatrizT_RespuestasDetalle_preguntaId_fkey" FOREIGN KEY ("preguntaId") REFERENCES "MatrizT_Detalle"("id") ON DELETE RESTRICT ON UPDATE CASCADE;


'use client'

import { useState, useMemo } from 'react'
import { format, addDays, isAfter, isBefore, differenceInDays } from 'date-fns'
import { saveMitigacionAction } from './actions'
import { useRouter } from 'next/navigation'
import MitigacionFileUploader from './MitigacionFileUploader'

const PROBLEM_VALUES = ['NO', 'NO_EXISTE', 'MALO_NO_CUMPLE', 'NO_HAY_REQUIERE']

export default function MitigacionClient({ 
    initialEvaluaciones, 
    initialMitigaciones,
    cutoffDate 
}: { 
    initialEvaluaciones: any[], 
    initialMitigaciones: any[],
    cutoffDate: Date | string
}) {
    const [evaluaciones] = useState(initialEvaluaciones)
    const [mitigaciones, setMitigaciones] = useState(initialMitigaciones)
    const [semestre, setSemestre] = useState<1 | 2>(1)
    const [selectedEvaluacionId, setSelectedEvaluacionId] = useState<string | null>(null)
    const [saving, setSaving] = useState<string | null>(null)
    const [selectedImage, setSelectedImage] = useState<string | null>(null)
    const router = useRouter()

    const cutoff = new Date(cutoffDate)

    const filteredEvaluaciones = useMemo(() => {
        return evaluaciones.filter(evaluacion => {
            const evalDate = new Date(evaluacion.fechaIngreso)
            if (semestre === 1) return isBefore(evalDate, cutoff) || evalDate.getTime() === cutoff.getTime()
            return isAfter(evalDate, cutoff)
        })
    }, [evaluaciones, semestre, cutoff])

    const getProblems = (evaluacion: any) => {
        const problems: any[] = []
        
        // Match respuestas con detalles de la plantilla
        const respuestasMap = new Map(evaluacion.detalles.map((d: any) => [d.preguntaId, d]))
        const plantillaDetalles = evaluacion.cabecera?.detalles || []

        plantillaDetalles.forEach((pregunta: any) => {
            const respuesta = respuestasMap.get(pregunta.id)
            if (respuesta && PROBLEM_VALUES.includes((respuesta as any).valor)) {
                const mitigacion = mitigaciones.find(m => m.matrizId === evaluacion.id && m.preguntaId === pregunta.id)
                
                // Extraer días del nivel de riesgo configurado en la pregunta
                let days = 30
                if (pregunta.nivelRiesgo === 1) days = 90
                else if (pregunta.nivelRiesgo === 2) days = 60
                else if (pregunta.nivelRiesgo === 3) days = 30

                const deadline = addDays(new Date(evaluacion.fechaIngreso), days)
                const nivelStr = pregunta.nivelRiesgo === 1 ? 'Bajo (90d)' : pregunta.nivelRiesgo === 2 ? 'Medio (60d)' : pregunta.nivelRiesgo === 3 ? 'Alto (30d)' : 'No Configurado (30d)'

                // Extraer fotos originales de la respuesta
                let originalPhotos: string[] = []
                try {
                    if ((respuesta as any).adjuntoUrl) {
                        const parsed = JSON.parse((respuesta as any).adjuntoUrl)
                        originalPhotos = Array.isArray(parsed) ? parsed : [(respuesta as any).adjuntoUrl]
                    }
                } catch(e) {
                    if ((respuesta as any).adjuntoUrl) originalPhotos = [(respuesta as any).adjuntoUrl]
                }

                problems.push({
                    ...pregunta,
                    response: (respuesta as any).valor,
                    nivelRiesgoStr: nivelStr,
                    deadline,
                    mitigacion: mitigacion || null,
                    originalPhotos
                })
            }
        })
        return problems
    }

    const handleSave = async (matrizId: string, preguntaId: string, fechaSolucion: string, adjuntos?: string[]) => {
        const key = `${matrizId}-${preguntaId}`
        setSaving(key)
        const res = await saveMitigacionAction({
            matrizId,
            preguntaId,
            fechaSolucion,
            adjuntos
        })
        setSaving(null)
        if (res.success) {
            router.refresh()
        } else {
            alert(res.error)
        }
    }

    const selectedEvaluacion = evaluaciones.find(e => e.id === selectedEvaluacionId)
    const problemList = selectedEvaluacion ? getProblems(selectedEvaluacion) : []

    const sectionColors: Record<string, string> = {
        'PATIO_SERVICIO': 'bg-amber-100 text-amber-900 border-amber-300',
        'BODEGA': 'bg-orange-100 text-orange-950 border-orange-300',
        'COCINA': 'bg-emerald-100 text-emerald-950 border-emerald-300',
        'BANO': 'bg-cyan-100 text-cyan-950 border-cyan-300',
        'LEVANTAMIENTO_GENERAL': 'bg-blue-100 text-blue-950 border-blue-300'
    }

    return (
        <>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-20">
            {/* Sidebar de Evaluaciones */}
            <div className="lg:col-span-4 space-y-4">
                <div className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100">
                    <div className="flex p-1 bg-slate-100 rounded-2xl">
                        <button 
                            onClick={() => setSemestre(1)}
                            className={`flex-1 py-2 text-sm font-bold rounded-xl transition-all ${semestre === 1 ? 'bg-white shadow-sm text-cyan-700' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            1er Semestre
                        </button>
                        <button 
                            onClick={() => setSemestre(2)}
                            className={`flex-1 py-2 text-sm font-bold rounded-xl transition-all ${semestre === 2 ? 'bg-white shadow-sm text-cyan-700' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            2do Semestre
                        </button>
                    </div>
                </div>

                <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                    <div className="p-4 bg-slate-50 border-b border-gray-100">
                        <h3 className="font-bold text-slate-700 text-sm">Evaluaciones Matriz Riesgo</h3>
                    </div>
                    <div className="divide-y divide-gray-50 max-h-[600px] overflow-y-auto">
                        {filteredEvaluaciones.map(ev => {
                            const problems = getProblems(ev)
                            const solved = problems.filter(p => p.mitigacion?.fechaSolucion).length
                            const pct = problems.length > 0 ? Math.round((solved / problems.length) * 100) : 100
                            
                            return (
                                <div 
                                    key={ev.id} 
                                    onClick={() => setSelectedEvaluacionId(ev.id)}
                                    className={`p-4 cursor-pointer transition-all hover:bg-slate-50 ${selectedEvaluacionId === ev.id ? 'bg-cyan-50 border-l-4 border-cyan-500' : ''}`}
                                >
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <p className="font-black text-slate-900 text-sm">RBD: {ev.rbd}</p>
                                            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">{format(new Date(ev.fechaIngreso), 'dd/MM/yyyy HH:mm')}</p>
                                            <p className="text-xs text-cyan-700 mt-1">{ev.cabecera?.titulo} ({ev.cabecera?.anio})</p>
                                        </div>
                                        <div className={`px-2 py-0.5 rounded text-[10px] font-black ${pct === 100 ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'}`}>
                                            {pct}% Avance
                                        </div>
                                    </div>
                                    <div className="mt-2 text-[11px] text-slate-600 font-bold grid grid-cols-2 gap-2">
                                        <div className="flex items-center gap-1">
                                            <span className="text-orange-500">⚠️</span> {problems.length} Hallazgos
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <span className="text-emerald-500">✅</span> {solved} Soluciones
                                        </div>
                                    </div>
                                    <div className="mt-3 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                        <div className={`h-full transition-all duration-500 ${pct === 100 ? 'bg-emerald-500' : 'bg-orange-500'}`} style={{ width: `${pct}%` }}></div>
                                    </div>
                                </div>
                            )
                        })}
                        {filteredEvaluaciones.length === 0 && (
                            <div className="p-8 text-center text-slate-400 text-sm font-medium">
                                No hay evaluaciones en este periodo.
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Panel de Detalle de Mitigación */}
            <div className="lg:col-span-8">
                {selectedEvaluacion ? (
                    <div className="space-y-6">
                        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                            <h2 className="text-xl font-black text-slate-900">Hallazgos y Mitigación</h2>
                            <p className="text-sm text-slate-500 font-medium mt-1">RBD {selectedEvaluacion.rbd} - {format(new Date(selectedEvaluacion.fechaIngreso), 'dd MMMM yyyy')}</p>
                        </div>

                        <div className="space-y-4">
                            {problemList.map((p, idx) => {
                                const remaining = differenceInDays(p.deadline, new Date())
                                const isExpired = remaining < 0 && !p.mitigacion?.fechaSolucion
                                
                                return (
                                    <div key={p.id} className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden flex flex-col">
                                        <div className={`px-6 py-3 flex justify-between items-center bg-slate-50`}>
                                            <span className={`text-[10px] font-black uppercase tracking-widest text-slate-600`}>
                                                SECCIÓN: {p.seccion.replace('_', ' ')}
                                            </span>
                                            <div className="flex gap-2">
                                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border ${p.nivelRiesgo === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : p.nivelRiesgo === 2 ? 'bg-yellow-50 text-yellow-700 border-yellow-100' : 'bg-red-50 text-red-700 border-red-100'}`}>
                                                    RIESGO: {p.nivelRiesgoStr}
                                                </span>
                                            </div>
                                        </div>
                                        <div className="p-6">
                                            <p className="text-slate-800 font-bold text-sm leading-relaxed">{p.preguntaNombre}</p>
                                            <div className="mt-2 p-2 bg-slate-50 rounded-xl text-xs text-slate-500 border border-slate-100 italic">
                                                Respuesta del usuario: <span className="font-bold text-slate-700">{p.response}</span>
                                            </div>

                                            {p.originalPhotos?.length > 0 && (
                                                <div className="mt-4">
                                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-2">Evidencia Original</p>
                                                    <div className="flex flex-wrap gap-2">
                                                        {p.originalPhotos.map((photo: string, i: number) => (
                                                            <div 
                                                                key={i} 
                                                                onClick={() => setSelectedImage(photo)}
                                                                className="w-16 h-16 rounded-xl bg-slate-100 overflow-hidden cursor-pointer hover:ring-4 hover:ring-cyan-500/30 transition-all shadow-sm border border-slate-200"
                                                            >
                                                                <img src={photo} alt="Evidencia" className="w-full h-full object-cover" />
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}

                                            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-slate-50">
                                                {/* Plazos */}
                                                <div>
                                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-2">Seguimiento de Plazos</p>
                                                    <div className="space-y-2">
                                                        <div className="flex justify-between items-center bg-slate-50 p-3 rounded-2xl border border-slate-100">
                                                            <span className="text-xs font-bold text-slate-600">Fecha Tope</span>
                                                            <span className="text-xs font-black text-slate-900">{format(p.deadline, 'dd/MM/yyyy')}</span>
                                                        </div>
                                                        <div className={`flex justify-between items-center p-3 rounded-2xl border ${p.mitigacion?.fechaSolucion ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : isExpired ? 'bg-red-50 border-red-100 text-red-700' : 'bg-cyan-50 border-cyan-100 text-cyan-700'}`}>
                                                            <span className="text-xs font-bold">Estado</span>
                                                            <span className="text-xs font-black">
                                                                {p.mitigacion?.fechaSolucion ? 'RESUELTO' : isExpired ? `VENCIDO (${Math.abs(remaining)} días)` : `PENDIENTE (${remaining} días rest.)`}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Acciones */}
                                                <div>
                                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-2">Completar Solución</p>
                                                    <div className="space-y-3">
                                                        <div>
                                                            <label className="text-[10px] font-bold text-slate-500 ml-1">FECHA DE SOLUCIÓN</label>
                                                            <input 
                                                                type="date"
                                                                defaultValue={p.mitigacion?.fechaSolucion ? format(new Date(p.mitigacion.fechaSolucion), 'yyyy-MM-dd') : ''}
                                                                onBlur={(e) => handleSave(selectedEvaluacion.id, p.id, e.target.value, p.mitigacion?.adjuntos ? JSON.parse(p.mitigacion.adjuntos) : undefined)}
                                                                className="w-full mt-1 bg-slate-50 border border-slate-200 rounded-2xl p-2.5 text-xs font-bold text-slate-900 focus:ring-2 focus:ring-cyan-500 outline-none"
                                                            />
                                                        </div>
                                                        <div>
                                                            <p className="text-[10px] font-bold text-slate-500 ml-1 mb-2">EVIDENCIAS (MÁX. 4)</p>
                                                            <MitigacionFileUploader 
                                                                initialFiles={p.mitigacion?.adjuntos ? JSON.parse(p.mitigacion.adjuntos) : []}
                                                                onUpload={(paths) => handleSave(selectedEvaluacion.id, p.id, p.mitigacion?.fechaSolucion ? format(new Date(p.mitigacion.fechaSolucion), 'yyyy-MM-dd') : '', paths)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                            {problemList.length === 0 && (
                                <div className="bg-emerald-50 border border-emerald-100 p-12 rounded-3xl text-center">
                                    <div className="text-5xl mb-4">✅</div>
                                    <h3 className="text-emerald-800 font-black text-xl">¡Sin Hallazgos Pendientes!</h3>
                                    <p className="text-emerald-600 mt-2 font-medium">Esta evaluación cumple con todos los puntos críticos del semestre.</p>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className="bg-white p-20 rounded-[40px] shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
                        <div className="w-24 h-24 bg-slate-50 rounded-[35px] flex items-center justify-center text-4xl mb-6 border border-slate-100 animate-pulse">
                            🔍
                        </div>
                        <h3 className="text-2xl font-black text-slate-900">Seleccione una Evaluación</h3>
                        <p className="text-slate-500 mt-3 max-w-sm text-lg font-medium">Elija un colegio del listado izquierdo para gestionar sus hallazgos de mitigación.</p>
                    </div>
                )}
            </div>
        </div>
            
            {/* Modal para ver imagen */}
            {selectedImage && (
                <div 
                    className="fixed inset-0 z-[100] bg-slate-900/90 flex items-center justify-center p-4 backdrop-blur-sm transition-opacity"
                    onClick={() => setSelectedImage(null)}
                >
                    <div className="relative max-w-5xl max-h-[90vh] flex flex-col items-center animate-in fade-in zoom-in-95 duration-200">
                        <button 
                            className="absolute -top-12 right-0 w-10 h-10 bg-white/10 hover:bg-red-500 text-white rounded-full flex items-center justify-center text-2xl font-bold transition-colors"
                            onClick={() => setSelectedImage(null)}
                        >
                            &times;
                        </button>
                        <img 
                            src={selectedImage} 
                            alt="Evidencia Ampliada" 
                            className="max-w-full max-h-[85vh] object-contain rounded-2xl shadow-2xl ring-1 ring-white/10"
                            onClick={(e) => e.stopPropagation()}
                        />
                    </div>
                </div>
            )}
        </>
    )
}

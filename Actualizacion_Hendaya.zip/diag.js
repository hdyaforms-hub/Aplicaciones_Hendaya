
const { PrismaClient } = require('@prisma/client')
const nodemailer = require('nodemailer')

const prisma = new PrismaClient()

async function testConnection(config) {
  console.log('--- Testing SMTP Connection ---')
  const transporter = nodemailer.createTransport({
    host: "smtp.office365.com",
    port: 587,
    secure: false,
    auth: {
      user: config.email,
      pass: config.password
    }
  })

  try {
    await transporter.verify()
    console.log('SMTP Connection: SUCCESS')
    return true
  } catch (err) {
    console.error('SMTP Connection: FAILED', err.message)
    console.log('Details:', err)
    return false
  }
}

async function main() {
  console.log('--- Database Diagnostic ---')
  
  const emailConfig = await prisma.emailConfig.findFirst({ where: { id: "global" } })
  if (!emailConfig) {
    console.log('Email Config (global): NOT FOUND')
  } else {
    console.log('Email Config found for:', emailConfig.email)
    await testConnection(emailConfig)
  }

  const notificationConfigs = await prisma.notificacionPantalla.findMany({
    where: { codigoPantalla: 'retiro-saldos' },
    include: { listaCorreo: true }
  })
  console.log('Retiro Notification Configs count:', notificationConfigs.length)
  notificationConfigs.forEach(c => {
    console.log(`- List: ${c.listaCorreo.nombre}, Active: ${c.activa}, Emails: ${c.listaCorreo.para}`)
  })
}

main()
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect())

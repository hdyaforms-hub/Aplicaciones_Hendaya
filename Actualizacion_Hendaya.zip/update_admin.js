
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function update() {
  const adminRole = await prisma.role.findUnique({ where: { name: 'Administrador' } });
  if (adminRole) {
    let perms = JSON.parse(adminRole.permissions);
    if (!perms.includes('view_solicitud_gas')) perms.push('view_solicitud_gas');
    if (!perms.includes('view_solicitud_gas_report')) perms.push('view_solicitud_gas_report');
    
    await prisma.role.update({
      where: { id: adminRole.id },
      data: { permissions: JSON.stringify(perms) }
    });
    console.log('Admin permissions updated:', perms);
  } else {
    console.log('Admin role not found');
  }
}

update().finally(() => prisma.$disconnect());
